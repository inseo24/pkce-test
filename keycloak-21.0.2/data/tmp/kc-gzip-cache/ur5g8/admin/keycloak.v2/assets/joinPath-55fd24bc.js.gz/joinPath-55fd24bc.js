const i="/";function c(...n){return n.map((s,t)=>{const o=t===0,r=t===n.length-1;return!o&&s.startsWith(i)&&(s=s.slice(1)),!r&&s.endsWith(i)&&(s=s.slice(0,-1)),s},[]).join(i)}export{c as j};
//# sourceMappingURL=joinPath-55fd24bc.js.map
