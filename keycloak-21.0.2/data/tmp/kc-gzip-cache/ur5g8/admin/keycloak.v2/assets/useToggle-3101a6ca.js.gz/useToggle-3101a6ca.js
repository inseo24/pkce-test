import{r as t}from"./index-2f311ada.js";function r(a=!1){const[s,e]=t.useState(a),o=t.useCallback(()=>e(u=>!u),[]);return[s,o,e]}export{r as u};
//# sourceMappingURL=useToggle-3101a6ca.js.map
