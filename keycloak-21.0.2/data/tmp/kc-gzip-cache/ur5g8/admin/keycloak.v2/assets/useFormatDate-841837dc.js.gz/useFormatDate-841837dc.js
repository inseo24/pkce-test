import{o as n}from"./index-2f311ada.js";const c={dateStyle:"long",timeStyle:"short"};function l(){const{whoAmI:t}=n(),o=t.getLocale();return function(e,a){return e.toLocaleString(o,a)}}export{c as F,l as u};
//# sourceMappingURL=useFormatDate-841837dc.js.map
