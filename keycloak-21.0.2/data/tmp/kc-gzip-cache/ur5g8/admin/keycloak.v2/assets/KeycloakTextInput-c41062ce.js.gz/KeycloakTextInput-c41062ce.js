import{r as n,j as s,az as p}from"./index-2f311ada.js";const x=n.forwardRef(({onChange:t,...a},r)=>{const e=(u,o)=>t?.(o);return s.jsx(p,{...a,ref:r,onChange:e})});x.displayName="TextInput";export{x as K};
//# sourceMappingURL=KeycloakTextInput-c41062ce.js.map
